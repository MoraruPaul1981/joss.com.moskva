


import '../Polo/Personjboss.dart';

abstract  class IntPoJoJboss {

  //todo  Person2
  Personjboss  fromJsonPerson2(Map<String, Personjboss> json) ;
  Map<String, Personjboss> toJsonPerson2() ;
  Map<String, Personjboss> toJson2Person2() ;





  //todo  dynamic
  Personjboss  fromJsondynamic(Map<String, dynamic> json) ;
  Map<String, dynamic> toJsondynamic() ;
  Map<String, dynamic> toJson2dynamic() ;





}




