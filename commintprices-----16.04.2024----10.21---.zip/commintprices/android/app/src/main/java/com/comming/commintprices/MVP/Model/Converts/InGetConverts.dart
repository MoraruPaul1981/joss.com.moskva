import 'dart:typed_data';

import 'package:flutter/material.dart';

//TODO
 abstract class InGetConverts  {
  //TODO base64
  String? convertBase64({required String user, required String  password});

  //TODO base64URL
  String? convertBase64URL({required String user, required String  password});
}


