


import '../Polo/Person1C.dart';

abstract  class  InParserJson1c {


  List<Person1C> parserPerson(String responseBody) ;



}















