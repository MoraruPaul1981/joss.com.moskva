





import '../Polo/Person1C.dart';

abstract  class InPolos2 {

  //todo  Person2
  //todo  dynamic
 Person1CTwo  fromJsondynamic({ required Map<String, dynamic> json}) ;

 Person1CTwo loopGwerenetorPolo(Map<String, dynamic> json);







}




