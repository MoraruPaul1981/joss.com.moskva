


import '../Polo/Personjboss.dart';

abstract  class  InParserJsonJboss {

  List<Personjboss> parserPerson(String responseBody) ;

}













