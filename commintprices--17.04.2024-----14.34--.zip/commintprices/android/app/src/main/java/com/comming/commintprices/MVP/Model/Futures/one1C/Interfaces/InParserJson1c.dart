


import 'package:http/http.dart';

import '../../../Jsons/One1C/Polo/Person1C.dart';

abstract  class  InParserJson1c {



  List<dynamic> getList1cDynamic({ required Response response1C}) ;

   String  getPingDynamicDontaunt({ required Response response1C}) ;

}















