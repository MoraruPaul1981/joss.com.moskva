
import 'package:dart_json_mapper/dart_json_mapper.dart';
import 'package:http/http.dart';

import '../../../Jsons/One1C/Polo/Person1C.dart';
import '../../../Jsons/One1C/Polo/Person1Cspoler.dart';






abstract  class InGetGZip1C {
  //TODO
  String getGZipCSting({ required Response response1C}) ;
  //TODO
  List<int> getGZip1CList({ required Response response1C}) ;

/*   final decoded_data = GZipCodec().decode(response1C.bodyBytes);
          String d=  utf8.decode(decoded_data, allowMalformed: true);*/
//  final  List<int> uint8listget1CPrices=     response1C.bodyBytes  ;

}








