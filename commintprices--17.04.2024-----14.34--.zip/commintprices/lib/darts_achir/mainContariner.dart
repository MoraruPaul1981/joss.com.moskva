import 'dart:io';

import 'package:flutter/material.dart';

void main() {
  try{

    runApp(
        Container(
          color: Colors.red,
        )
    );




    //BL b=  BL();
    print(" main class BL Hello !!!! " );

    //TODO error
  }   catch (e, stacktrace) {
    print(' get ERROR $e get stacktrace $stacktrace ');
  }
}






