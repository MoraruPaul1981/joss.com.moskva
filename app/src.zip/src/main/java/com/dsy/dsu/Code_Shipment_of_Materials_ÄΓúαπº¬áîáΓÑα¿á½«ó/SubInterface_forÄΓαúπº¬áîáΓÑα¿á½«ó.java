package com.dsy.dsu.Code_Shipment_of_Materials_ОтгрузкаМатериалов;

  interface SubInterface_forОтргузкаМатериалов {

    StringBuffer МеханизмПолучениеданныхИзФрагмента(StringBuffer stringBuffer);



}
