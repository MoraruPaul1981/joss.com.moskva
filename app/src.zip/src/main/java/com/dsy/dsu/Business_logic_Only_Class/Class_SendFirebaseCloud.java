package com.dsy.dsu.Business_logic_Only_Class;

public class Class_SendFirebaseCloud {


    public Class_SendFirebaseCloud() {

    String BASE_URL="https://fcm.googleapis.com";

    String SERVER_KEY="AAAATKc-2wM:APA91bFUTs5e9UnHqf9oTQG0HkNB0rhPeAv4qP3d63dtCw1N7s-Qloemz4bEkAdzSxm8jRkUPHk9aPR8JjBVaQQ6DmTqPVWySy9RsOC3S784kUYfYwBht1Jxs_drQKgKUWB_SDaUfHl_";

     String CONTENT_TYPE="application/json";
    }
}
