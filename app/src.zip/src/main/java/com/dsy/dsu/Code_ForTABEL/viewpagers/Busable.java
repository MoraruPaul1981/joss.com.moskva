package com.dsy.dsu.Code_ForTABEL.viewpagers;

import android.database.Cursor;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.ViewPager;

public interface Busable {
    ViewPager viewPager();
}
