package com.dsy.dsu.AllDatabases.modelJSON;

public class ParentJsonClass {
    void p(){

    }
}
