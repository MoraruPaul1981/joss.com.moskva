package com.dsy.dsu.AllDatabases.JsonDeserializer;

import io.reactivex.rxjava3.core.Flowable;

public class JsonMainDeseirialzer {
   private Flowable flowableJson=null;

    public void setFlowableJson(Flowable flowableJson) {
        this.flowableJson = flowableJson;
    }
}
