package com.dsy.dsu.Code_Gson_Processing;

import android.util.Log;

public class SubClass_JSON_B_P_POST_1C_shipment_of_materials<LinkedBlockingDeque>  {


    // Public fields are included in the JSON data by default
    private Integer Statusshipment_of_materialsFromAndroid;
    private String Documentshipment_of_materialsFromAndroid;

    public SubClass_JSON_B_P_POST_1C_shipment_of_materials(Integer statusshipment_of_materialsFromAndroid, String documentshipment_of_materialsFromAndroid) {
        Statusshipment_of_materialsFromAndroid = statusshipment_of_materialsFromAndroid;
        Documentshipment_of_materialsFromAndroid = documentshipment_of_materialsFromAndroid;
    }
}
